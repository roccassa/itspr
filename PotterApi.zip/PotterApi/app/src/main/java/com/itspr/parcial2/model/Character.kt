package com.itspr.parcial2.model

import com.google.gson.annotations.SerializedName

data class CharacterResponse(
    val results: List<Character>
)

data class Character(
    val id: Int,
    @SerializedName("image") val image: String?,
    @SerializedName("name") val name: String,
    @SerializedName("house") val house: String?,
    @SerializedName("gender") val gender: String?,
)